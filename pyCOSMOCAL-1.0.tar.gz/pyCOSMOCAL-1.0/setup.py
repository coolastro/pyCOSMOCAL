from distutils.core import setup
setup(name='pyCOSMOCAL',
      version='1.0',
      description="Python GUI for Ned Wright Calculator",
      author="Bhargav Vaidya",
      author_email="B.Vaidya@leeds.ac.uk",
      url="http://www.ast.leeds.ac.uk/~phybva/Bhargav_Vaidya/Simulations.html",
      scripts=['bin/CosmoCal.py'],
      py_modules=['cosmocal_nongui']
     )


